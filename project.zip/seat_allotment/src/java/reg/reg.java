
package reg;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class reg extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title> regisrtered user</title>");            
            out.println("</head>");
            out.println("<body bgcolor='pink'>");
             HttpSession ss = request.getSession();
        
             ss.setAttribute("nname", request.getParameter("nname"));
             ss.setAttribute("fname", request.getParameter("fname"));
             ss.setAttribute("gender", request.getParameter("gender"));
             ss.setAttribute("address", request.getParameter("address"));
             ss.setAttribute("password", request.getParameter("password")); 
             ss.setAttribute("qual1", request.getParameter("qual1")); 
             ss.setAttribute("dob", request.getParameter("dob")); 
             ss.setAttribute("qual2", request.getParameter("qual2")); 
             ss.setAttribute("roll", request.getParameter("roll"));
             ss.setAttribute("score", request.getParameter("score")); 
            out.println(" <center><h1><u>Welcome to JEE Seat Allotment System</u></h1></center><br>\n" +"<center><h3> Your details are as follows:</h3></center> ");
            out.println("<form action='start.html' method='post'>");
            out.println("<center><fieldset>\n" +
"                 <legend>Personal Information:</legend>\n" +
"                 <table>\n" +
"                 <tr><td>Name:</td><td>"+request.getParameter("nname")+"</td></tr>" +
"                 <tr><td>Father's Name:</td><td>"+request.getParameter("fname")+"</td></tr>\n" +
"                 <tr><td>Gender:</td><td>"+request.getParameter("gender")+"</td></tr>\n" +
"                 <tr><td>Address:</td><td>"+request.getParameter("address")+"</td></tr>\n" +
"                 <tr><td>Date of Birth:</td><td>"+request.getParameter("dob")+"</td></tr>\n" +
"                 <tr><td>Password:</td><td>"+request.getParameter("password")+"</td></tr>\n" +
"                 </table>\n" +
"                 </fieldset>\n" +
"             </center>\n" +
"             <br>\n" +
"             <center>\n" +
"                 <fieldset>\n" +
"                 <legend>Academic Information:</legend>\n" +
"             <table>\n" +
"                 <tr><td>Qualification:</td><td>"+request.getParameter("qual1") +"</td><td>"+request.getParameter("qual2")+"</td></tr>\n" +
"                 <tr><td>Enrollment No:</td><td>"+request.getParameter("roll")+"</td><tr>                         \n" +
"                 <tr><td>Score:</td><td>"+request.getParameter("score")+"</td></tr>\n" +
"                 \n" +
"                 </table>\n" +
"                 </fieldset>");
            out.println("<center>Click below to update or submit your information.Please see your information carefully</center><br>");
            out.println("<center><input type='submit' value ='submit info'><a href='update'><input type ='button' value='update'></a>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
