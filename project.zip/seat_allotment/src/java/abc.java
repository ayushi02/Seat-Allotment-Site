/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DELL LAPI
 */
public class abc extends HttpServlet {

    public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
    {
        PrintWriter out = response.getWriter();
        
        response.setContentType("text/html");
        
        int x=10;
        //String d = request.getParameter("nname");
        
        //out.print(d);
    
       /* Cookie c = new Cookie("A", String.valueOf(x));
        
        response.addCookie(c);
        
        out.print("abc servlet");
        
        
        HttpSession ss = request.getSession();
        
        ss.setAttribute("B", "Hello");
        */
       
       /* if(x==10)
        {
            RequestDispatcher rd = request.getRequestDispatcher("zz");
            rd.forward(request, response);
                    
        }
        else
        {
            //RequestDispatcher rd = request.getRequestDispatcher("zz");
            //rd.include(request, response);
            
            response.sendRedirect("http://www.yahoo.com/");
            
        }*/
         out.print("<a href='zz'>visit</a>"); 
        out.print("abc servlet");
    }
}
