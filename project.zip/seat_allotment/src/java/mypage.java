import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class mypage extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) 
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>mypage</title>");            
            out.println("</head>");
            out.println("<body bgcolor='orange'>");
            HttpSession user = request.getSession(false);
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/seat", "root","root");
            Statement smt=con.createStatement();
            ResultSet rs=smt.executeQuery("select * from student where name="+user.getAttribute("username")+"password="+user.getAttribute("password"));
            while(rs.next())
            {
                out.println("<center>Welcome :"+rs.getString(2)+"<br> Your Score is : "+rs.getInt(11)+"</center>");
            }
            out.println("Enter your choices below:<br>");
            out.println("<center><table>");
            out.println("<tr><th>COLLEGE NAME</th><th>BRANCH</th></tr>");
            out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");
            out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");
            out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");
            out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");
            out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");
out.println("<tr><td><select>\n" +
"  <option value='MANIT'>MANIT</option>\n" +
"  <option value='IIIT>IIIT</option>\n" +
"  <option value='SGSITS'>SGSITS</option>\n" +
"  <option value='DAVV'>DAVV</option>\n" +
"  <option value='MITS'>MITS</option>\n" +
"</select></td><td><select>\n" +
"  <option value='CSE'>CSE</option>\n" +
"  <option value='ECE'>ECE</option>\n" +
"  <option value='EEE'>EEE</option>\n" +
"  <option value='Mech.'>Mech.</option>\n" +
"  <option value='Civil'>Civil</option>\n" +
"  <option value='Metallurgy'>Metallurgy</option>\n" +                    
"</select>");

out.println("</table></center><br>");
out.println("<center><input type='submit' value ='submit response'></center>");            
            out.println("</body>");
            out.println("</html>");
        }
    }

}    