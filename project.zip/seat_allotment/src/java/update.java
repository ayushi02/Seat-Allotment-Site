
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DELL LAPI
 */
public class update extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet update</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Up date your response</h1>");
             HttpSession k = request.getSession();
            out.println("<div>\n" +
"            <center><h1><u>Welcome to JEE Seat Allotment System</u></h1></center><br>\n" +
"      <center><h3>Please update your details below</h3></center>\n" +
"         <form action='reg' method='post'>\n" +
"             <center>\n" +
"                 <fieldset>\n" +
"                 <legend>Personal Information:</legend>\n" +
"                 <table>\n" +
"                 <tr><td>Name:</td><td><input type='text' name=\"nname\" value="+k.getAttribute("nname")+" ></td></tr>\n" +
"                 <tr><td>Father's Name:</td><td><input type=\"text\" name=\"fname\" value="+k.getAttribute("fname")+" ></td></tr>\n" +
"                 <tr><td>Gender:</td><td><input type=\"text\" name=\"gender\" value="+k.getAttribute("gender")+" > </td></tr>\n"+
"                 <tr><td>Address:</td><td><textarea rows=\"4\" cols=\"50\" name=\"address\">"+k.getAttribute("address")+"</textarea></td></tr>\n" +
"                 <tr><td>Date of Birth:</td><td><input type=\"text\" name=\"dob\" value="+k.getAttribute("dob")+"></td></tr>\n" +
"                 <tr><td>Password:</td><td><input type=\"text\" name=\"password\" value="+k.getAttribute("password")+" ></td></tr>\n" +
"                 </table>\n" +
"                 </fieldset>\n" +
"             </center>\n" +
"             <br>\n" +
"             <center>\n" +
"                 <fieldset>\n" +
"                 <legend>Academic Information:</legend>\n" +
"             <table>\n" +
"                 <tr><td>Qualification:</td><td><input type=\"text\" name=\"qual1\" value="+k.getAttribute("qual1")+"><br>" +
"                  <tr><td>             </td><td><input type=\"text\" name=\"qual2\" value="+k.getAttribute("qual2")+"></td></tr>\n" +
"                 <tr><td>Enrollment No:</td><td><input type=\"text\" name=\"roll\" value="+k.getAttribute("roll")+"></td><tr>                         \n" +
"                 <tr><td>Score:</td><td><input type=\"text\" name=\"score\" value="+k.getAttribute("score")+"></td></tr>\n" +
"                 \n" +
"                 </table>\n" +
"                 </fieldset>");
             out.println("<center><input type='submit' value='submit info'></center>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
