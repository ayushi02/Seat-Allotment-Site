
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class reg_done implements Filter {
    
    private static final boolean debug = true;
    
    private FilterConfig filterConfig = null;
    
    public reg_done() {
    }    
    
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
        
        if (debug) {
            log("reg_done:doFilter()");
        }
               
                PrintWriter out=response.getWriter();
                HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String url = req.getServletPath();
		boolean allowedRequest = false;
		out.println("in filter");
	        HttpSession session = req.getSession(false);
                if(session!=null)
                {
                 try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con;
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/seat", "root","root");
                String name=(String) session.getAttribute("nname");
                String fname=(String) session.getAttribute("fname");
                String gender=(String) session.getAttribute("gender");
                String address=(String) session.getAttribute("address");
                int date=(int)session.getAttribute("dob");
                String password=(String) session.getAttribute("password");
                String qual1=(String) session.getAttribute("qual1");
                String qual2=(String) session.getAttribute("qual2");
                int roll=(int)session.getAttribute("roll");
                int score=(int)session.getAttribute("score");
               
                PreparedStatement ps;
           
                ps = con.prepareStatement("insert into student(name,fname,gender,address,date,password,qualification1,qualification2,enrollment,score) values(?,?,?,?,?,?,?,?,?,?)");
                ps.setString(2,name);
                ps.setString(3,fname);
                ps.setString(4,gender);
                ps.setString(5,address);
                ps.setInt(6,date);
                ps.setString(7,password);
                ps.setString(8,qual1);
                ps.setString(9,qual2);
                ps.setInt(10,roll);
                ps.setInt(11,score);
            int ii=ps.executeUpdate();
            if(ii>0)
            {
                out.println("Data entered successfully");
            }
            else
            {
                out.println("Unable to update the database");
            }
                }
            catch(Exception e)
            {
               e.printStackTrace(); 
            }
          }
                else
                {
                    out.println("no data");
                }
        Throwable problem = null;
        try {
            chain.doFilter(request, response);
        } catch (Throwable t) {
	   
            problem = t;
            t.printStackTrace();
        }
        
             

        if (problem != null) {
            if (problem instanceof ServletException) {
                throw (ServletException) problem;
            }
            if (problem instanceof IOException) {
                throw (IOException) problem;
            }
            sendProcessingError(problem, response);
        }
    }

    public FilterConfig getFilterConfig() {
        return (this.filterConfig);
    }

    public void setFilterConfig(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
    }

    public void destroy() {        
    }

    public void init(FilterConfig filterConfig) {        
        this.filterConfig = filterConfig;
        if (filterConfig != null) {
            if (debug) {                
                log("reg_done:Initializing filter");
            }
        }
    }

    @Override
    public String toString() {
        if (filterConfig == null) {
            return ("reg_done()");
        }
        StringBuffer sb = new StringBuffer("reg_done(");
        sb.append(filterConfig);
        sb.append(")");
        return (sb.toString());
    }
    
    private void sendProcessingError(Throwable t, ServletResponse response) {
        String stackTrace = getStackTrace(t);        
        
        if (stackTrace != null && !stackTrace.equals("")) {
            try {
                response.setContentType("text/html");
                PrintStream ps = new PrintStream(response.getOutputStream());
                PrintWriter pw = new PrintWriter(ps);                
                pw.print("<html>\n<head>\n<title>Error</title>\n</head>\n<body>\n"); 
                pw.print("<h1>The resource did not process correctly</h1>\n<pre>\n");                
                pw.print(stackTrace);                
                pw.print("</pre></body>\n</html>"); //NOI18N
                pw.close();
                ps.close();
                response.getOutputStream().close();
            } catch (Exception ex) {
            }
        } else {
            try {
                PrintStream ps = new PrintStream(response.getOutputStream());
                t.printStackTrace(ps);
                ps.close();
                response.getOutputStream().close();
            } catch (Exception ex) {
            }
        }
    }
    
    public static String getStackTrace(Throwable t) {
        String stackTrace = null;
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            t.printStackTrace(pw);
            pw.close();
            sw.close();
            stackTrace = sw.getBuffer().toString();
        } catch (Exception ex) {
        }
        return stackTrace;
    }
    
    public void log(String msg) {
        filterConfig.getServletContext().log(msg);        
    }
    
}
